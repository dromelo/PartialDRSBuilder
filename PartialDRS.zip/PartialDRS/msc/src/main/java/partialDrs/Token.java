package partialDrs;

public class Token {
	String deprel, xpos, lemma, upos, text, feats, misc, var;
	boolean evar = false, eent = false;
	Long id, head;
	public Token(String deprel, String xpos, String lemma, String upos, String text, String feats, String misc, Long id,
			Long head) {
		super();
		this.deprel = deprel;
		this.xpos = xpos;
		this.lemma = lemma;
		this.upos = upos;
		this.text = text;
		this.feats = feats;
		this.misc = misc;
		this.id = id;
		this.head = head;
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Token other = (Token) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (id != other.id)
			return false;
		if (head == null) {
			if (other.head != null)
				return false;
		} else if (head != other.head)
			return false;
		if (deprel == null) {
			if (other.deprel != null)
				return false;
		} else if (!deprel.equals(other.deprel))
			return false;
		if (upos == null) {
			if (other.upos != null)
				return false;
		} else if (!upos.equals(other.upos))
			return false;
		if (lemma == null) {
			if (other.lemma != null)
				return false;
		} else if (!lemma.equals(other.lemma))
			return false;
		return true;
	}



	@Override
	public Object clone() throws CloneNotSupportedException{
		Token t = new Token(deprel, xpos, lemma, upos, text, feats, misc, id, head);
		t.evar = this.evar;
		t.eent = this.eent;
		t.var = this.var;
		return t;
	}
	
	@Override
	public String toString() {
		return "\nToken [deprel=" + deprel + ", xpos=" + xpos + ", lemma=" + lemma + ", upos=" + upos + ", text=" + text
				+ ", feats=" + feats + ", misc=" + misc + ", id=" + id + ", head=" + head + ", var=" + var + ", evar=" + evar 
				+ ", eent=" + eent + "]";
	}
}
