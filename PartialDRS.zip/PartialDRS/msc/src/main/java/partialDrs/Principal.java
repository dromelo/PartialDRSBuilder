package partialDrs;

import java.util.ArrayList;

public class Principal {
	static ArrayList<Drs> finalListDrs = new ArrayList<Drs>();
	
	private static final Long Long = null;
	
	public static void main(String[] args) {
		System.out.println("start");
		String frase; 
		frase = "Which papers did Dan O. Popa publish in the last 9 years?";
		
		String filePartialDRS = "data-nlquery/partialDRS.txt";
		long startTime = System.currentTimeMillis();  
		System.out.println(frase + "\n");
		Modulo1 m1 = new Modulo1(frase, filePartialDRS);		
		System.out.println("Finished in " + (System.currentTimeMillis() - startTime) / 1000.0 + "s\n");		
	}
}
