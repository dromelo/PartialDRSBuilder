package partialDrs;

import java.util.ArrayList;



public class Drs {
	Integer num = 0;
	ArrayList<Token> tokens = new ArrayList<Token>(); //árvore sintática
	ArrayList<DEntity> dEntities = new ArrayList<DEntity>(); //lista de entidades
	ArrayList<DCondition> dConditions = new ArrayList<DCondition>(); //lista de condições
	ArrayList<String> entities = new ArrayList<String>();
	
	Drs(ArrayList<Token> tokens){ this.tokens = tokens; }
	
	Drs(ArrayList<DEntity> dEntities, ArrayList<DCondition> dConditions){
		this.dEntities = dEntities;
		this.dConditions = dConditions;
	}
	
	Drs(ArrayList<Token> tokens, ArrayList<DEntity> dEntities, ArrayList<DCondition> dConditions){
		this.tokens = tokens;
		this.dEntities = dEntities;
		this.dConditions = dConditions;
	}
	Drs(){};
	
	public ArrayList<DCondition> dConditionsClone(){
		ArrayList<DCondition> aux = new ArrayList<DCondition>();
		for(DCondition e : dConditions) {
			try {
				aux.add((DCondition) e.clone());
			} catch (CloneNotSupportedException e1) {
				e1.printStackTrace();
			}
		}
		return aux;
	}
	public ArrayList<DEntity> dEntitiesClone(){
		ArrayList<DEntity> aux = new ArrayList<DEntity>();
		for(DEntity e : dEntities) {
			try {
				aux.add((DEntity) e.clone());
			} catch (CloneNotSupportedException e1) {
				e1.printStackTrace();
			}
		}
		return aux;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dConditions == null) ? 0 : dConditions.hashCode());
		result = prime * result + ((dEntities == null) ? 0 : dEntities.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Drs other = (Drs) obj;
		if (dConditions == null) {
			if (other.dConditions != null)
				return false;
		} else {
			for(DCondition d : dConditions) {
				if(!other.dConditions.contains(d)) return false; 
			}
			for(DCondition d : other.dConditions) {
				if(!this.dConditions.contains(d)) return false; 
			}
		}
			
		if (dEntities == null) {
			if (other.dEntities != null)
				return false;
		} else {
			for(DEntity d : dEntities) {
				if(!other.dEntities.contains(d)) return false; 
			}
			for(DEntity d : other.dEntities) {
				if(!this.dEntities.contains(d)) return false; 
			}
		}
		return true;
	}
	public DEntity getEntity(String chave) {
	    for(DEntity e: dEntities) {
	        if(e.var.equals(chave)) { return e; }
	    }
	    return null;
	}
	

	
	public void adjustVars() {
		
		for (int i=1; i <=  this.dEntities.size();i++) {		
		   String varNome= "X" + Integer.toString(i);
		   while (this.getEntity(varNome)==null) { 
			   this.adjustVars(varNome) ;
		   }
	    }
	}
	
	public void adjustVars(String varName) {
		int value1;		
		int value = Integer.parseInt(varName.replaceAll("[^0-9]", ""));
		for (DEntity e:this.dEntities) {
			value1 = Integer.parseInt(e.var.replaceAll("[^0-9]", ""));
			if (value1 >  value) e.var="X" + Integer.toString(value1-1);
		}
		for (DCondition e:this.dConditions) {
			value1 = Integer.parseInt(e.varDomain.replaceAll("[^0-9]", ""));
			if (value1 > value) e.varDomain="X" + Integer.toString(value1-1);
			String str=e.rangeValue.replaceAll("[0-9]", "");
			if (str.equals("X")) {
				value1 = Integer.parseInt(e.rangeValue.replaceAll("[^0-9]", ""));
				if (value1 > value) e.rangeValue="X" + Integer.toString(value1-1);}
		};
	}
	
	public void addAllE(ArrayList<DEntity> lista) {
		for(DEntity e: lista) {
			if(!this.dEntities.contains(e)) {
				try {
					this.dEntities.add((DEntity) e.clone());
				} catch (CloneNotSupportedException e1) {
					e1.printStackTrace();
				}
			}
		}
	}
	
	public void addAllC(ArrayList<DCondition> lista) {
		for(DCondition e: lista) {
			if(!this.dConditions.contains(e)) {
				try {
					this.dConditions.add((DCondition) e.clone());
				} catch (CloneNotSupportedException e1) {
					e1.printStackTrace();
				}
			}
		}
	}
	
	
	public Token getToken(String deprel) {
		for(Token t: tokens) {
			if(t.deprel.equals(deprel)) {
				//System.out.println("encontrou");
				return t;
			}
		}
		return null;
	}	
	
	public Token getToken(String deprel, String car) {
		for(Token t: tokens) {
			if(t.deprel.equals(deprel) && t.text.equals(car)) {
				return t;
			}
		}
		return null;
	}
	
	public Token getToken(Long head, String deprel, Long head1) {
		//System.out.println("head = " + head + " deprel = " + deprel + " head1 = " + head1);
		for(Token t: tokens) {
			if(t.head.equals(head) && t.deprel.equals(deprel) && t.id > head1) {
				//System.out.println("encontrou");
				return t;
			}
		}
		return null;
	}

	
	public int tokenSize() {
		return tokens.size();
	}
	
	@Override
	public String toString() {
		return "Drs [\n tokens=" + tokens + ",\n dEntities=" + dEntities + ",\n dConditions=" + dConditions + "]";
	}
}
