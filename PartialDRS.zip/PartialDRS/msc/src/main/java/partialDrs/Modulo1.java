package partialDrs;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import guru.nidi.graphviz.attribute.Color;
import guru.nidi.graphviz.attribute.Label;
import guru.nidi.graphviz.engine.Format;
import guru.nidi.graphviz.engine.Graphviz;
import guru.nidi.graphviz.model.Graph;

public class Modulo1 {

	public Modulo1(String frase, String fileOut) {
		stanzaAnalysisUni(frase);

		Drs d = syntacticRep();
		ArrayList<Drs> ld = new ArrayList<Drs>();
		ld.add(buildDRS(d));
		System.out.println("Partial DRS: "+ld);
		guardarDRSmodulo1(ld,fileOut);
	}



	private void stanzaAnalysisUni(String frase) {
		String[] cmd = { "python", "data-nlquery/main.py", frase};
		Process proc;

		ProcessBuilder pb = new ProcessBuilder(cmd).redirectErrorStream(true); 
		try {
			proc = pb.start();
			System.out.println("Running Stanza...");
			InputStream stdin = proc.getInputStream();
			InputStreamReader isr = new InputStreamReader(stdin);
			BufferedReader br = new BufferedReader(isr);
			String line = null;
			System.out.println("<OUTPUT>");
			while ( (line = br.readLine()) != null)
				System.out.println(line); 
			System.out.println("</OUTPUT>");	        
			int exitVal = proc.waitFor();
			System.out.println("Process exitValue: " + exitVal);

		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	public Drs syntacticRep(){

		JSONParser parser = new JSONParser();

		try {
			ArrayList<Token> tokens = new ArrayList<Token>();
			Object obj = parser.parse(new FileReader("data-nlquery/out.json"));

			System.out.println(obj);

			JSONArray jsonArray =  (JSONArray) obj; 
			@SuppressWarnings("unchecked")
			Iterator<Object> it = jsonArray.iterator();
			while(it.hasNext()) {

				JSONObject jsonObject = (JSONObject) it.next();
				Token t = new Token((String) jsonObject.get("deprel"), (String) jsonObject.get("xpos"), 
						(String) jsonObject.get("lemma"), (String) jsonObject.get("upos"), 
						(String) jsonObject.get("text"), (String) jsonObject.get("feats"), 
						(String) jsonObject.get("misc"), (Long) jsonObject.get("id"), 
						(Long) jsonObject.get("head"));
				tokens.add(t);
			}
			Drs d = new Drs(tokens);
			return d;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public Token getToken(Long id, ArrayList<Token> tokens) {
		for(Token t: tokens) {
			if(t.id == id) {
				return t;
			}
		}
		return null;
	}

	public Token getToken(Long head, String deprel, ArrayList<Token> tokens) {
		for(Token t: tokens) {
			if(t.head.equals(head) && t.deprel.equals(deprel)) {
				//System.out.println("encontrou");
				return t;
			}
		}
		return null;
	}

	public DEntity getEntity(String chave, ArrayList<DEntity> dEntities) {
		for(DEntity e: dEntities) {
			if(e.var.equals(chave)) { return e; }
		}
		return null;
	}


	public void	changehead(Token tpai, Token trem, ArrayList<Token> tokens)
	{
		for (Token tr : tokens)
			if (tr.head==trem.id) tr.head=tpai.id;
	}
	public Drs buildDRS(Drs d) { 
		//flat
		ArrayList<Token> tremove = new ArrayList<Token>();
		for(Token t : d.tokens) {
			if(t.deprel.equals("flat")) {
				Token tpai = getToken(t.head,d.tokens);
				tpai.lemma = tpai.lemma + " " + t.lemma;
				tremove.add(t); 
				changehead(tpai,t,d.tokens);
			}
		}
		for(Token t : tremove) d.tokens.remove(t);
		//compound
		for(Token t : d.tokens) {
			if(t.deprel.equals("compound")) {
				Token tpai = getToken(t.head,d.tokens);
				if(!(t.upos.equals("PROPN") && tpai.upos.equals("NOUN"))) {
					tpai.lemma = t.lemma + " " + tpai.lemma;
					tremove.add(t);
					changehead(tpai,t,d.tokens);
				}
			}
			if(t.deprel.equals("appos")) {
				Token tpai = getToken(t.head,d.tokens);
				if((t.upos.equals("PROPN") && tpai.upos.equals("PROPN")&& !t.deprel.contains("conj"))) {
					tpai.lemma = t.lemma + " " + tpai.lemma;
					tremove.add(t);
					changehead(tpai,t,d.tokens);
				}	
			}
		}
		for(Token t : d.tokens) {
			if (t.deprel.equals("conj")&&t.upos.equals("PROPN")) {
				Token tpai = getToken(t.head,d.tokens);
				if (tpai.upos.equals("PROPN")&&tpai.deprel.contains("appos")) {
					Token tavo=getToken(tpai.head,d.tokens);
					t.deprel=tavo.deprel;
					t.head=tavo.head;
				}else {
					t.deprel=tpai.deprel;
					t.head=tpai.head;
				}
			}			
		}
		for(Token t : tremove) d.tokens.remove(t);
		DEntity e;
		DCondition dc;
		for(Token t : d.tokens) {
			switch (t.upos) {
			case "VERB" :
			case "NOUN" :
			case "PRON" :
				t.var = "X" + Integer.toString(++d.num);
				e = new DEntity(t.var,t.lemma,t.text,t.upos,null,t.id);
				d.dEntities.add(e);
				dc = new DCondition(e.var, "has_text", t.lemma);
				d.dConditions.add(dc);
				break;
			case "PROPN" :
				t.var = "X" + Integer.toString(++d.num);
				e = new DEntity(t.var,t.lemma,t.text,t.upos,null,t.id);
				d.dEntities.add(e);
				dc = new DCondition(e.var, "has_name", t.lemma);
				d.dConditions.add(dc);
				break;
			}
		}
		//conditions
		Token tcase, tpai;
		for(Token t : d.tokens) {
			switch (t.deprel) {
			case "compound" : 
				tpai = getToken(t.head,d.tokens);
				dc = new DCondition(tpai.var, "of", t.var);
				d.dConditions.add(dc);
				break;
			case "obl" :
				if (t.feats!=null&&!t.feats.contains("Rel")) {
					tcase = getToken(t.id, "case", d.tokens);
					tpai = getToken(t.head,d.tokens);
					dc = new DCondition(tpai.var, "obl_" + tcase.lemma, t.var);
					d.dConditions.add(dc);}
				break;
			case "obl:agent" :
				tcase = getToken(t.id, "case", d.tokens);
				tpai = getToken(t.head,d.tokens);
				if (tcase!=null){
					dc = new DCondition(tpai.var, "obl_" + tcase.lemma, t.var);}
				else {dc = new DCondition(tpai.var, "obl_by", t.var);}
				d.dConditions.add(dc);
				break;
			case "nmod" :
				tcase = getToken(t.id, "case", d.tokens);
				if (tcase!=null) {
					tpai = getToken(t.head,d.tokens);
					dc = new DCondition(tpai.var, tcase.lemma, t.var);
					d.dConditions.add(dc);}
				break;
			case "nsubj" :
				tpai = getToken(t.head,d.tokens);
				if(!tpai.upos.equals("VERB")) {
					if(tpai.upos.equals("PRON")) {                	 
						for (DCondition dc1 : d.dConditions) 
							if(dc1.varDomain == tpai.var) 
							{d.dConditions.remove(dc1); break;}
						d.dEntities.remove(d.getEntity(tpai.var)); 
						dc = new DCondition(t.var, tpai.lemma, "true");
						d.dConditions.add(dc);
					}
					else {	  
						Token tpaicop = getToken(tpai.id,"cop",d.tokens);
						if (tpaicop==null) tpaicop = getToken(tpai.id,"aux",d.tokens);
						tpaicop.var = "X" + Integer.toString(++d.num);
						e = new DEntity(tpaicop.var,tpaicop.lemma,tpaicop.text,"VERB",null,tpaicop.id);
						d.dEntities.add(e);
						dc = new DCondition(tpaicop.var, "subj", t.var);
						d.dConditions.add(dc);
						dc = new DCondition(tpaicop.var, "obj", tpai.var);
						d.dConditions.add(dc);
						dc = new DCondition(tpaicop.var, "has_text", tpaicop.lemma);
						d.dConditions.add(dc);			
					}}
				else {
					dc = new DCondition(tpai.var, "subj", t.var);
					d.dConditions.add(dc);
				}
				break;
			case "obj" :
				tpai = getToken(t.head,d.tokens);
				dc = new DCondition(tpai.var, "obj", t.var);
				d.dConditions.add(dc);
				break;
			case "nsubj:pass" : 
				tpai = getToken(t.head,d.tokens);
				if(!t.feats.contains("Rel")) {
					dc = new DCondition(tpai.var, "nsubj:pass", t.var);
					d.dConditions.add(dc);}
				break;
			case "acl" : 
				tpai = getToken(t.head,d.tokens);
				dc = new DCondition(t.var, "nsubj:pass", tpai.var);
				d.dConditions.add(dc);
				break;
			case "acl:relcl" : 
				tpai = getToken(t.head,d.tokens);
				Token tobl= getToken(t.id,"obl",d.tokens);
				if ((tobl!=null)&&tobl.feats.contains("Rel")) 
				{ tcase = getToken(tobl.id,"case",d.tokens);
				dc = new DCondition(t.var, "obl_"+tcase.lemma, tpai.var);
				d.dConditions.add(dc);
				d.dEntities.remove(d.getEntity(tobl.var)); }
				else {
					Token tsubjpass= getToken(t.id,"nsubj:pass",d.tokens);
					if (tsubjpass!=null)  
					{dc = new DCondition(t.var, "nsubj:pass", tpai.var);
					d.dConditions.add(dc);
					d.dEntities.remove(d.getEntity(tsubjpass.var)); }
				}
				break;	
			case "det" :
				tpai = getToken(t.head,d.tokens);
				DEntity edet = getEntity(tpai.var, d.dEntities);
				edet.det = t.lemma;
				break;
			case "conj" : 
				tpai = getToken(t.head,d.tokens);
				if(!(t.upos.contains("PROPN")&&tpai.upos.contains("PROPN")))
					break;
			case "appos" :
				tpai = getToken(t.head,d.tokens);
				for (DCondition dc1 : d.dConditions) {
					if(dc1.varDomain.equals(t.var)) dc1.varDomain= tpai.var;}
				d.dEntities.remove(d.getEntity(t.var)); 
				break;
			case "amod" :
			case "advmod":	 
				tpai = getToken(t.head,d.tokens);
				dc = new DCondition(tpai.var, "mod", t.lemma);     
				d.dConditions.add(dc);
				break;
			case "nummod" :
				tpai = getToken(t.head,d.tokens);
				dc = new DCondition(tpai.var, "number", t.lemma);     
				d.dConditions.add(dc);
				break;
			}
		}
		d.adjustVars();
		return d;	
	}


	public static void guardarDRSmodulo1(ArrayList<Drs> listDrs, String fileOut) {
		try {
			PrintWriter out = new PrintWriter(new FileWriter(fileOut));
			for(Drs d : listDrs) {
				//out.write(d.dEntities.size() + "\n");
				for(DEntity e : d.dEntities) {
					out.append(e.var + "#" + e.lemma + "#" + e.word + "#" + e.upos + "#" + e.det + "#" + e.id + ",");
				}
				out.append("\n");
				for(DCondition dc : d.dConditions) {
					out.append(dc.varDomain + "#" + dc.prop + "#" + dc.rangeValue + ",");
				}
				out.append("\n");
			}

			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}