package partialDrs;


public class DEntity {
	String var,  lemma, word, upos, det;
	Long id;

	public DEntity(String var, String lemma, String word, String upos, String det, Long id) {
		this.var = var;
		this.lemma = lemma;
		this.word = word;
		this.upos = upos;
		this.det = det;
		this.id = id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((det == null) ? 0 : det.hashCode());
		result = prime * result + ((lemma == null) ? 0 : lemma.hashCode());
		result = prime * result + ((word == null) ? 0 : word.hashCode());
		result = prime * result + ((upos == null) ? 0 : upos.hashCode());
		result = prime * result + ((var == null) ? 0 : var.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DEntity other = (DEntity) obj;
		if (det == null) {
			if (other.det != null)
				return false;
		} else if (!det.equals(other.det))
			return false;
		if (lemma == null) {
			if (other.lemma != null)
				return false;
		} else if (!lemma.equals(other.lemma))
			return false;
		if (word == null) {
			if (other.word != null)
				return false;
		} else if (!word.equals(other.word))
			return false;
		if (upos == null) {
			if (other.upos != null)
				return false;
		} else if (!upos.equals(other.upos))
			return false;
		if (var == null) {
			if (other.var != null)
				return false;
		} else if (!var.equals(other.var))
			return false;
		return true;
	}

	@Override
	public Object clone() throws CloneNotSupportedException{
		DEntity aux = new DEntity(this.var,this.lemma,this.word,this.upos,this.det,this.id);
		return aux;
	}
	@Override
	public String toString() {
		return "\nDEntity(" + var + ", " + lemma + ", " + word + ", " + upos + ", " + det + ")";
	}
	
	
	
}
