import stanza
import json
import sys

################################################################################
##### MAIN - START #####
#"The reason why this may not work, is because file is one of Python's core modules, so I suggest
#you change the name of your file."


def main():
    this_input = sys.argv[1] #frase lida da linha de comando

    #stanza.download('en') # download English model
    nlp = stanza.Pipeline('en') # initialize English neural pipeline
    #nlp = stanza.Pipeline('pt')

    #this_input = "Em 25 de fevereiro de 1840, o rato foi comido pelo gato."
    #this_input = "Documentação transferida do Governo Civil de Bragança em 15 de Novembro de 1994."
    #this_input = "Show products in details."

    print("\n\nInput:", this_input)
    doc = nlp(this_input)
    print(doc)
    #print(doc.sentences[0])
    #print(doc.sentences[0].words)
    x1 = doc.sentences[0].words
    x = []

    for elem in doc.sentences[0].words:
        xx = {}
        xx["id"] = elem.id
        xx["text"] = elem.text
        xx["lemma"] = elem.lemma
        xx["upos"] = elem.upos
        xx["xpos"] = elem.xpos
        xx["feats"] = elem.feats
        xx["head"] = elem.head
        xx["deprel"] = elem.deprel
        xx["misc"] = elem.misc
        x += [xx]

    y = json.dumps(x)
    f = open("out.json", "w")
    f.write(y)
    f.close()
    return 0




##### MAIN - END #####
#################################################################################################

#------------------------ início do fluxo de execução -----------
#instance_list = [inst for inst in list(onto.individuals())]
main()
#------------------------ fim do fluxo de execução -----------
